from pynput.keyboard import Key, Controller
import keyboard
import time



print('Working!!! Go back to Memrise')
keyboardPynput = Controller()

exitProgram = False
while True:
    keyboardPynput.press(Key.enter)

    keyboardPynput.release(Key.enter)
    currentTime = time.time()

    if exitProgram:
        break
    
    while True:
        
        if time.time() - currentTime > 0.5:
            break
        else:

            try:  # used try so that if user pressed other than the given key error will not be shown
                if keyboard.is_pressed('esc'):  # if key 'q' is pressed 
                    print('Ended System!')
                    exitProgram = True

                    break
                    

            except:
                pass










